<?php
ob_start();
 session_start();
 require "connect.php";
 extract($_POST);

    $flag=true;
    $result = $conn->query("SELECT EmployeeID,Name,Email,Password FROM `Employee`");
    $rows = $result->fetch_all(MYSQLI_ASSOC);
    foreach($rows as $row)
    {
        if($row['Email']==$EmployeeName&&$row['Password']==$EmployeePassword)
        {
            $_SESSION['userId'] = $row['EmployeeID']; 
            $_SESSION['Name'] = $row['Name']; 
            $flag=true;
            echo $flag;
        }
        else 
        {
            $flag=false;
        }
    }
    if(!$flag)
      echo $flag;
?>