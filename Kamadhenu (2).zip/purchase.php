<?php
include "connect.php";
session_start();
extract($_POST);
$result="";
$userId =$_SESSION["userId"];
if(isset($_REQUEST['month']))
{
    $month=$_REQUEST['month'];
    $monthName=$_REQUEST['monthName'];
    $year=$_REQUEST['year'];
        $query="SELECT SUM(Quantity) as Quantity FROM Sale where CustomerId =$userId and (select Extract(MONTH FROM Date))=$month and (select Extract(YEAR FROM Date))=$year";
        $stmt = mysqli_query($conn,$query);
  $result= "<table id='classTable' class='table table-striped table-condensed table-bordered'><thead><tr><th>Month</th><th>Quantity(in litres)</th></tr></thead><tr><td>$monthName</td>";
while($row = mysqli_fetch_assoc($stmt)) 
{
    $result.= "<td>".$row['Quantity']."</td></tr>";
}
}
else{
    $purchase_from=$_POST["from"];
    $dateArr =explode(" to ",$purchase_from);
    $dateArr[0]=date_format(date_create_from_format('d-m-Y',$dateArr[0]),'Y-m-d');
    $dateArr[1]=date_format(date_create_from_format('d-m-Y',$dateArr[1]),'Y-m-d');
    $query="SELECT Date,Quantity  FROM Sale where CustomerId =$userId and date between '".$dateArr[0]."' and '".$dateArr[1]."'";
    $stmt = mysqli_query($conn,$query);
  $result= "<table id='classTable' class='table table-striped table-condensed table-bordered'><thead><tr><th>Date</th><th>Quantity(in litres)</th></tr></thead><tbody class='tablescroll'>";
while($row = mysqli_fetch_assoc($stmt)) 
{
    $result.= "<tr><td>".$row['Date']."</td><td>".$row['Quantity']."</td></tr>";
}
   $query="SELECT sum(Quantity) as total FROM Sale where CustomerId =$userId and date between '".$dateArr[0]."' and '".$dateArr[1]."'";
   $stmt= mysqli_query($conn,$query);
   $row=mysqli_fetch_assoc($stmt);
   $result.= "Sum Purchased in Interval = ".$row['total']." litres";

}


echo $result."</tbody></table>";
?>
