<?php
 include "connect.php";
 extract($_POST);
    if(isset($_REQUEST['amount']))
    {
      $stmt = $conn->prepare("INSERT INTO Payment (CustomerID, Date, Amount) VALUES (?, ?, ?)");
      $stmt->bind_param("iss", $customer, $paidon, $amount);
      if($stmt->execute())
        echo "Successfully Paid";
      else
        echo "Try Again";
    }
    else
    {
      $sql = "SELECT Name,Result.bill,Mobileno FROM (SELECT Due.CustomerID,ifnull(SUM(Amount),0)-Due.c as bill FROM (SELECT CustomerID,Cost*(M.s) as c FROM (SELECT CustomerID,SUM(Quantity) as s FROM Sale GROUP BY(CustomerID)) as M,Milk WHERE Milk.MilkID= (SELECT MilkID FROM Customer where CustomerID=M.CustomerID)) as Due LEFT JOIN Payment ON Due.CustomerID=Payment.CustomerID GROUP BY CustomerID UNION SELECT Payment.CustomerID,SUM(Amount)-ifnull(Due.c,0) FROM (SELECT CustomerID,Cost*(M.s) as c FROM (SELECT CustomerID,SUM(Quantity) as s FROM Sale GROUP BY(CustomerID)) as M,Milk WHERE Milk.MilkID= (SELECT MilkID FROM Customer where CustomerID=M.CustomerID)) as Due RIGHT JOIN Payment ON Due.CustomerID=Payment.CustomerID GROUP BY CustomerID) as Result,Customer WHERE Result.CustomerID=Customer.CustomerID";
      $result = mysqli_query($conn, $sql);
      $resultTable= "<table id='DueTable' class='table table-striped table-condensed table-bordered'><thead><tr><th>Customer</th><th>Due</th><th>Mobile Number</th></tr></thead>";
      if (mysqli_num_rows($result) > 0)
      {
        // output data of each row
         while($row = mysqli_fetch_assoc($result))
         {
             $resultTable.= "<tr><td>".$row['Name']."</td><td>".$row['bill']."</td><td>".$row['Mobileno']."</td></tr>";
         }
         echo $resultTable."</table>";
      } 
      else 
      {
          echo "0 results";
      }
    }
?>