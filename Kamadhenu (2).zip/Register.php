<?php
 include "connect.php";
 extract($_POST);
 $bool = 1;
 date_default_timezone_set("Asia/Calcutta");
    $state='Telangana';
    $address = $conn->prepare("INSERT INTO Address (Line1, Line2, City, State, Pincode) VALUES (?, ?, ?, ?, ?)");
    $address->bind_param("sssss", $line1, $line2, $city , $state, $zip);
    if($address->execute())
    {
       $addressid = $conn->insert_id;
       $date =  date('Y-m-d');
       if(isset($_REQUEST['quant']))
       {
          $parametertypes="ssssiidis";
          $stmt = $conn->prepare("INSERT INTO Customer (Name,Mobileno,Email,Password,AddressID,MilkID,Quantity,Status, DateOfRegistration) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
          $stmt->bind_param($parametertypes, $name, $phone, $email, $phone, $addressid,$milk,$quant,$bool,$date);
          if($stmt->execute())
          {
            echo "Successfully Registered\n";
            echo "Login Details are Email is $email and $phone (Mobileno) is Password";
            $subject="Welcome to Kamadhenu Dairy";
             $txt="Hi ".$name.",<br><br>";
             $txt.="Kamadhenu Dairy welcomes you to the world of pure milk.Now enjoy pure and safe milk everyday.Your login credentials are <br><br>";
             $txt.="Email : ".$email."<br>";
             $txt.="Password : ".$phone."<br>";
             $txt.="Thank You,<br>Kamadhenu Dairy";
             $headers = "From: no-reply@kamadhenu.com" . "\r\n";
             $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
             $to = $email;
             mail($to,$subject,$txt,$headers);
          }
          else
             echo "Try Again failed to register";
        }
       else
       {
          $parametertypes="sdsssis";
          $stmt = $conn->prepare("INSERT INTO Employee (Name,Salary,Mobileno,Email,Password,AddressID, DateOfJoining) VALUES (?, ?, ?, ?, ?, ?, ?)");
          $stmt->bind_param($parametertypes, $name, $salary, $phone, $email,$phone, $addressid,$doj);
          if($stmt->execute())
          {
             echo "Successfully Registered Employee\n";
             echo "Login Details are Email is $email and $phone (Mobileno) is Password";
             $subject="Welcome to Kamadhenu Dairy";
             $txt="Hi ".$name.",<br><br>";
             $txt.="Kamadhenu Dairy welcomes you to the world of pure milk.Hope you have bright future ahead.Your login credentials are <br><br>";
             $txt.="Email : ".$email."<br>";
             $txt.="Password : ".$phone."<br>";
             $txt.="Thank You,<br>Kamadhenu Dairy";
             $headers = "From: no-reply@kamadhenu.com" . "\r\n";
             $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
             $to = $email;
             mail($to,$subject,$txt,$headers);
          }
          else
             echo "Try Again Failed to Register";
       } 
    }
    else
     {
         echo "Try Again\n";
         //echo $line1." ".$line2." ".$city." ".$state." ".$zip;
     }
?>