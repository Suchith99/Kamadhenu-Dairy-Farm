var phonevalid=true;
var emailvalid=true;
var namevalid=true;
function validatePhone()
{
    var mobile=$("#mobile").val();
    var phoneNumberRegExp = new RegExp(/^[0]?[789]\d{9}$/); //new RegExp('^([0|\+[0-9]{1,5})?([7-9][0-9]{9})$');
    if(!phoneNumberRegExp.test(mobile))
    {
        $("#mobileauthentication").html("*Enter Correct mobile number");
        phonevalid = false;  
    }
    else
    {
        $("#mobileauthentication").html("");
        phonevalid = true;
    }
}
function validateName()
{
    var customer=$("#newCustomerName").val();
    if(customer==="")
    {
        namevalid=false;
        $("#Nameauthentication").html("*Enter valid name");
    }
    else
    {
        namevalid=true;
         $("#Nameauthentication").html("");
    }
}
function validateEmail()
{
    var Email=$("#CustomerEmail").val();
    var emailReg = new RegExp(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/);
    if(!emailReg.test(Email)||Email==="")
    {
        emailvalid= false;
        $("#emailauthentication").html("*Enter Correct Email");
    }
    else
    {
        emailvalid=true;
         $("#emailauthentication").html("");
    }
}
function customerRegister()
{
    validateName();
    validatePhone();
    validateEmail();
    if(phonevalid&&emailvalid&&namevalid)
    {
       var customer=$("#newCustomerName").val();
       var milk=$("#Milk").val();
       var line1=$("#Address").val();
       var quantity=$("#DailyQuantity").val();
       var mobile=$("#mobile").val();
       var city=$("#city").val();
       var ZIP=$("#ZIP").val();
       var Email=$("#CustomerEmail").val();
       var line2=$("#Line2").val();
    if(line1!==""&&quantity!==""&&city!==null&&milk!==null)
    {
       var frm = document.getElementById('CustomerRegistrationForm');
       $("#CustomerForm").fadeOut("fast");
       frm.reset(); 
       $.post("Register.php",{name:customer,milk:milk,quant:quantity,line1:line1,line2:line2,city:city,zip:ZIP,email:Email,phone:mobile},function(data){
        alert(data);
       });
    }
    }
}
var Ephonevalid=true;
var Eemailvalid=true;
var Enamevalid=true;
function EvalidatePhone()
{
    var mobile=$("#Emobile").val();
    var phoneNumberRegExp = new RegExp(/^(\+)?(91)?( )?[789]\d{9}$/); //new RegExp('^([0|\+[0-9]{1,5})?([7-9][0-9]{9})$');
    if(!phoneNumberRegExp.test(mobile))
    {
        $("#Emobileauthentication").html("*Enter Correct mobile number");
        Ephonevalid = false;  
    }
    else
    {
        $("#Emobileauthentication").html("");
        Ephonevalid = true;
    }
}
function EvalidateName()
{
    var customer=$("#newEmployeeName").val();
    if(customer==="")
    {
        Enamevalid=false;
        $("#ENameauthentication").html("*Enter valid name");
    }
    else
    {
        Enamevalid=true;
         $("#ENameauthentication").html("");
    }
}
function EvalidateEmail()
{
    var Email=$("#EmployeeEmail").val();
    var emailReg = new RegExp(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/);
    if(!emailReg.test(Email)||Email==="")
    {
        emailvalid= false;
        $("#Eemailauthentication").html("*Enter Correct Email");
    }
    else
    {
        emailvalid=true;
         $("#Eemailauthentication").html("");
    }
}
function employeeRegister()
{
    EvalidateName();
    EvalidatePhone();
    EvalidateEmail();
    if(Ephonevalid&&Eemailvalid&&Enamevalid)
    {
       var employee=$("#newEmployeeName").val();
       var line1=$("#EAddress").val();
       var salary=$("#Salary").val();
       var mobile=$("#Emobile").val();
       var city=$("#Ecity").val();
       var ZIP=$("#EZIP").val();
       var Email=$("#EmployeeEmail").val();
       var line2=$("#ELine2").val();
       var doj=$("#DOJ").val();
    if(line1!==""&&salary!==""&&city!==null&&doj!=="")
    {
       var frm = document.getElementById('EmployeeRegistrationForm');
       $("#EmployeeForm").fadeOut("fast");
       frm.reset(); 
       $.post("Register.php",{name:employee,doj:doj,salary:salary,line1:line1,line2:line2,city:city,zip:ZIP,email:Email,phone:mobile},function(data){
        alert(data);
       });
    }
    }
}