<?php
extract($_GET);
?>
<!DOCTYPE html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <script src="https://www.paypal.com/sdk/js?client-id=sb"></script>
    </head>
    <body>
    <h4>Customer Name : <span id="Customer"><?php echo $name?></span></h4>
    <h4>Amount : <span id="amount"><?php echo $money ?></span></h4>
    <script>
    var money=document.getElementById("amount").innerHTML;
    //alert(money);
    paypal.Buttons({
        createOrder: function(data, actions) {
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                           // currency_code:"INR",
                            value: money
                        }
                    }]
                });
            },
 /*   createOrder: function(data, actions) {
      return actions.order.create({
          curl -v -X POST https://api.sandbox.paypal.com/v2/checkout/orders \
-H "Content-Type: application/json" \
-H "Authorization: Basic client_id: ECHUVn8yg2BEihQiPTwUzwOjLPlYPV6-bGkFPYxrQf881nYwMLHiXkQUBaa-mw2M3xav4owz48ygFmUU" \
-d '{
  "intent": "CAPTURE",
  "purchase_units": [
    {
      "amount": {
        "currency_code": "INR",
        "value": "100.00"
      }
    }
  ]
}'
          
    /*    client_id: "ECHUVn8yg2BEihQiPTwUzwOjLPlYPV6-bGkFPYxrQf881nYwMLHiXkQUBaa-mw2M3xav4owz48ygFmUU",
        intent: "CAPTURE",
       purchase_units: [{
          amount: {
            
            value: money
          }
        }]*/
        
/*        curl -v -X POST https://api.sandbox.paypal.com/v2/checkout/orders \
-H "Content-Type: application/json" \
-H "Authorization: Bearer Access-Token" \
-d '{
  "intent": "CAPTURE",
  "purchase_units": [
    {
      "amount": {
        "currency_code": "USD",
        "value": "100.00"
      }
    }
  ]
}'
      });
    },*/
    onApprove: function(data, actions) {
      return actions.order.capture().then(function(details) {
        alert('Transaction completed by ' + details.payer.name.given_name);
        // Call your server to save the transaction
  return fetch('/PayPal-PHP-SDK-1.14.0/Verification.php', {
          method: 'post',
          headers: {
            'content-type': 'application/json'
          },
          body: JSON.stringify({
            orderID: data.orderID,
            customer:<?php echo $CustomerID?>,
            amount:<?php echo $money ?>,
          })
        });
       // alert('Transaction completed okkkk ' + details.payer.name.given_name);
      });
      
    }
  }).render('body');</script>
    
    </body>
</html>