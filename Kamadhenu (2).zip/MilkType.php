<?php
 include "connect.php";
 $result = $conn->query("SELECT MilkID,Cost,Description FROM `Milk`");
    $milktype = $result->fetch_all(MYSQLI_ASSOC);
 ?>