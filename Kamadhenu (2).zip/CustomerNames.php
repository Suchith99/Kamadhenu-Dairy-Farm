<?php
 include "connect.php";
 $result = $conn->query("SELECT Name,CustomerID FROM `Customer`");
    $rows = $result->fetch_all(MYSQLI_ASSOC);
 ?>