function absentNotification()
{
    var reason=$("#reason").val();
    var dates =$("#absentdates").val();
    //alert("Reason "+reason+" On "+dates);
    $.post("customerNotify.php",{dates:dates,reason:reason},function(){
        alert("Successfully Informed");
    });
  /*  var absentDates=dates.split(",");
    for(i=0;i<absentDates.length;i++)
    {
        $.post("customerNotify.php",{date:absentDates[i],reason:reason},function(data){});
    }
    if(from.indexOf("to")!=-1)
    {
        $("#p-from").html(from);
        $("#interval-payment").fadeIn("fast");
       $.post("customerNotify.php",{from:from},function(data){
       document.getElementById('table_content_payment').innerHTML=data;
    });
    }
    else
      alert("Select Dates");*/
}
function extraNotification()
{
    var dates =$("#extradates").val();
    var extraDates=dates.split(" , ");
    for(i=0;i<extraDates.length;i++)
    {
        var quantity=$("#"+extraDates[i]).val();
        $.post("customerNotify.php",{date:extraDates[i],quantity:quantity});
    }
    alert("Successfully Informed");
}