<?php

namespace PayPalCheckoutSdk\Core;


use BraintreeHttp\Injector;

class GzipInjector implements Injector
{
    public function inject($httpRequest)
    {
        $httpRequest->headers["Accept-Encoding"] = "gzip";
    }
}