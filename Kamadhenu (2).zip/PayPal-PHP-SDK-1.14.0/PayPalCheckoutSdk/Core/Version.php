<?php

namespace PayPalCheckoutSdk\Core;

class Version
{
    const VERSION = "2.0.0-rc2";
}
