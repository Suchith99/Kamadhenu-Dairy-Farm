<?php
$servername = "localhost";
$username = "id8679313_ganesh";
$password = "lord219";
$databasename="id8679313_kamadhenudairy";
$conn = new mysqli($servername, $username, $password, $databasename);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 			
?>