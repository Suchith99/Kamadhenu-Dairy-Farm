<?php
ob_start();
session_start();
include "CustomerDates.php"
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kamadhenu Dairy Farm</title>
    <meta name="description" content="">
    <meta name="keywords" content="ace student portal">
    <meta name="author" content="fudio">

    <link rel="shortcut icon" href="img/ace1.png" type="image/x-icon">

    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.css">


    <link rel="stylesheet" href="css/nivo-lightbox.css">
    <link rel="stylesheet" href="css/nivo_lightbox_themes/default/default.css">



    <!-- Stylesheet
    ================================================== -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
    <link rel="stylesheet" type="text/css" href="css/style1.css">
    <link rel="stylesheet" type="text/css" href="css/animate1.css">

    <!-- Google Fonts
    ================================================== -->
    <link href='https://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css'>

    <script type="text/javascript" src="js/modernizr.custom.js"></script>
<script src="PurchaseHistory.js"></script>
<script src="PaymentHistory.js"></script>
<script src="Notify.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery.1.11.1.js"></script>

    <script>
      function closeModal()
      {
        $("#interval-purchase").fadeOut("fast");
      }
      function closePayment() {
          $("#interval-payment").fadeOut("fast");
      }
       function closeHistory() {
          $("#previous-payment").fadeOut("fast");
      }
      function closeModal2() {
          $("#monthly").fadeOut("fast");
      }
      function extraNotify() {
          $("#extra-notify").fadeIn("fast");
      }
      function extraNotifyClose() {
          $("#extra-notify").fadeOut("fast");
      }
      function absentNotify() {
          $("#absent-dates").html($("#absentdates").val());
          $("#absent-notify").fadeIn("fast");
      }
      function absentNotifyClose() {
          $("#absent-notify").fadeOut("fast");
      }
      function proceedtopay()
      { 
          var id=<?php echo $_SESSION['userId']?>;
          var money= document.getElementById('Amount').value;
          var cust= <?php echo "'".$_SESSION['Name']."'"?>;
          alert(money);
          window.location ="PaymentGateway.php?CustomerID="+id+"&money="+money+"&name="+cust;
         // $.post('PaymentGateway.php');//,{Amount:money,CustomerID:".$userId."});
        //  header('Location: PaymentGateway.php?id='.$userId);
      }
    </script>
    
</head>
<body>
    

    <!-- Main Navigation
    ================================================== -->
    <nav id="tf-menu" class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img src="img/ace1.png" alt="..."></a>
            </div>
            <input type="hidden" id="userId" value="<?php echo $_SESSION['userId']?>">
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#tf-home" class="scroll">Home</a></li>
                    <li><a href="#tf-process1" class="scroll">Purchases</a></li>
                    <li><a href="#tf-works" class="scroll">Payments</a></li>
                    <li><a href="#tf-process" class="scroll">Notify us</a></li>
                    <li><a href="#tf-blog" class="scroll">Notices</a></li>
                    <li><a href="#tf-contact" class="scroll">Contact us</a></li>
                    <li><a href ="Logout.php" style="color:blue">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Home Section
    ================================================== -->
    <div id="tf-home">
        <div class="overlay">
            <div class="container">
                <div class="content-heading text-center">
                    <h1>Kamadhenu Dairy Farm</h1>
                    <p class="lead">...where purity is met</p>
                    <a href="#" class="scroll goto-btn text-uppercase">
                        <?php
                        if(isset($_SESSION['userId'])){
                            echo "<span>Welcome</span>"." ".$_SESSION['Name'];
                        }
                       ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Intro Section
    ================================================== -->
    <div id="tf-intro">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <img src="img/logo-w.png" class="intro-logo img-responsive" alt="sssuu">
                    <p>Kamadhenu Dairy Farm is established with the motive to provide pure milk to the people of Warangal.</p>
                </div>

            </div>
        </div>
    </div>



    <!-- my info pillagada
    ================================================== -->
    <div id="tf-process1">
        <div id="tf-features">
            <div class="container">
                <div class="section-header">
                    <h2>Purchase<span class="highlight"><strong>INFO</strong></span></h2>
                    <h5><em>Have a smile</em></h5>
                    <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                </div>
            </div>
            <div id="feature" class="gray-bg">
                <div class="container">
                    <div class="row" role="tabpanel">
                        <div class="col-md-4 col-md-offset-1">
                            <ul class="features nav nav-pills nav-stacked" role="tablist">
                                <li role="presentation" class="active">
                                    <a href="#f1" aria-controls="f1" role="tab" data-toggle="tab">
                                        <span class="fa fa-pencil"></span>
                                        Interval Purchase<br><small></small>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#f2" aria-controls="f2" role="tab" data-toggle="tab">
                                        <span class="fa fa-pencil"></span>
                                        Monthwise Purchase<br><small></small>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-6">

                            <div class="tab-content features-content">
                                <div role="tabpanel" class="tab-pane fade in active" id="f1">
                                    <h4>Select from and to dates</h4>                          
                                        <div class="form-group">
                                            <!-- From Date -->                    
                                            <input autocomplete="off" class="form-control from-to_datepicker" placeholder="Select from and to Dates" id="purchase-from" name="purchase-from" readonly>          
                                        </div>
                                          <div class="text-center">
                                            <input type="button" class="btn btn-primary tf-btn color margin-bottom-medium" value="Submit" onclick="intervalPurchase();">
                                        </div>
                                    
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="f2">
                                    <div class="form-group">
                                        <label for="month">Select Month :</label>
                                        <select class="form-control" id="month">
                                            <option disabled selected value> -- Select a Month -- </option>
                                            <option value="January">January</option>
                                            <option>February</option>
                                            <option>March</option>
                                            <option>April</option>
                                            <option>May</option>
                                            <option>June</option>
                                            <option>July</option>
                                            <option>August</option>
                                            <option>September</option>
                                            <option>October</option>
                                            <option>November</option>
                                            <option>December</option>
                                        </select>
                                        <label for="year">Select Year :</label>
                                        <select class="form-control" id="year">
                                            <option>2019</option>
                                            <option>2018</option>
                                            <option>2017</option>
                                            <option>2016</option>
                                        </select>
                                        <div class="text-center">
                                            <input type="button" class="btn btn-primary tf-btn color margin-bottom-medium" value="Display" onclick="monthlyPurchase()">
                                        </div>
                                    </div>
                               <!--   <h4>Click the button for monthly purchase</h4>  
                                      <form action="/action_page.php">
                                        <div class="text-center">
                                            <input type="submit" class="btn btn-primary tf-btn color margin-bottom-medium" value="Display">
                                        </div>
                                    </form>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Modal to display results-->
    <div class="trans_purchase_result" id="interval-purchase">   
            <div class="modal-dialog modal-lg">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" onclick="closeModal()">&times;</button>
                        <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                    </div>
                    <div class="modal-body" id="summary">
                        <h5 style="text-align:left">Quantity purchased : <span id="p-from"></span></h5>
                    </div>
                    <div class="modal-body" id="view-details" style="display:none">
                        <h5>Purchase Details</h5>
                        <div id="table_content"></div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal" id="view-button" >View Details</button>
                    </div>
                </div>
            </div>
    </div>

    <div class="trans_purchase_result" id="monthly">
        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" onclick="closeModal2()">&times;</button>
                    <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                </div>
                <div class="modal-body" id="summary">
                    <h5 style="text-align:left">Quantity purchased : </h5>
                </div>
                <div class="modal-body" id="view-details">
                    <h5>Purchase Details</h5>
                   <div id="table_content_monthly"></div>
                </div>
                
            </div>
        </div>
    </div>
            <!-- Payments Section
               ================================================== -->
            <div id="tf-works">
                <div id="tf-features">
                    <div class="container">
                        <div class="section-header">
                            <h2>Payments<span class="highlight"><strong>INFO</strong></span></h2>
                            <h5><em>Have a smile</em></h5>
                            <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                        </div>
                    </div>
                    <div id="feature" class="gray-bg">
                        <div class="container">
                            <div class="row" role="tabpanel">
                                <div class="col-md-4 col-md-offset-1">
                                    <ul class="features nav nav-pills nav-stacked" role="tablist">
                                        <li role="presentation" class="active">
                                            <a href="#f11" aria-controls="f11" role="tab" data-toggle="tab">
                                                <span class="fa fa-pencil"></span>
                                                Interval Payments<br><small></small>
                                            </a>
                                        </li>
                                        <li role="presentation">
                                            <a href="#f22" aria-controls="f22" role="tab" data-toggle="tab">
                                                <span class="fa fa-pencil"></span>
                                                PAY NOW<br><small></small>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <div class="tab-content features-content">
                                        <div role="tabpanel" class="tab-pane fade in active" id="f11">
                                            <h4>Select from and to dates</h4>
                                            <form action="/action_page.php">
                                                <div class="form-group">
                                                    <!-- To Date -->
                                                    <input autocomplete="off" class="from-to_datepicker form-control" placeholder="Select from and to Dates" id="payment-interval" name="payment-interval">
                                                </div>
                                                <div class="text-center">
                                                    <input type="button" class="btn btn-primary tf-btn color margin-bottom-medium" value="Submit" onclick="intervalPayment()">
                                                </div>
                                            </form>
                                        </div>
                                        <div role="tabpanel" class="tab-pane fade" id="f22">
                                            <h4>Click the button for checking dues</h4>
                                            <form action="/action_page.php">
                                                <div class="text-center">
                                                    <input type="button" class="btn btn-primary tf-btn color margin-bottom-medium" value="Check" onclick="paymentHistory()">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           
           <!--Modal to display results-->
    <div class="trans_purchase_result" id="interval-payment">   
            <div class="modal-dialog modal-lg">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" onclick="closePayment()">&times;</button>
                        <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                    </div>
                    <div class="modal-body" id="payment-summary">
                        <h5 style="text-align:left">Payments Made : <span id="payment-interval"></span></h5>
                    </div>
                    <div class="modal-body" id="view-payments-details" style="display:block">
                        <h5>Payments Details</h5>
                        <div id="table_content_payment"></div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal" id="view-payments" >View Details</button>
                    </div>
                </div>
            </div>
    </div>

    <div class="trans_purchase_result" id="previous-payment">
        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" onclick="closeHistory()">&times;</button>
                    <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                </div>
                <div class="modal-body" id="history">
                    <h5 style="text-align:left">Payment Made : </h5>
                </div>
                <div class="modal-body" id="view-details">
                    <h5>Payment Details</h5>
                   <div id="table_content_history"></div>
                </div>
                
            </div>
        </div>
    </div>
            <!-- news
            ================================================== -->
            <div id="tf-process">
                <div id="tf-features">
                    <div class="container">
                        <div class="section-header">
                            <h2>Notify<span class="highlight"><strong>Us</strong></span></h2>
                            <h5><em>Have a smile</em></h5>
                            <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                        </div>
                    </div>
                    <div id="feature" class="gray-bg">
                        <div class="container">
                            <div class="row" role="tabpanel">
                                <div class="col-md-4 col-md-offset-1">
                                    <ul class="features nav nav-pills nav-stacked" role="tablist">
                                        <li role="presentation" class="active">
                                            <a href="#f13" aria-controls="f13" role="tab" data-toggle="tab">
                                                <span class="fa fa-pencil"></span>
                                                Absent Note<br><small></small>
                                            </a>
                                        </li>
                                        <li role="presentation">
                                            <a href="#f23" aria-controls="f23" role="tab" data-toggle="tab">
                                                <span class="fa fa-pencil"></span>
                                                Extra Note<br><small></small>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <div class="tab-content features-content">
                                        <div role="tabpanel" class="tab-pane fade in active" id="f13">
                                            <h4>Select dates you are unavailable</h4>
                                            <form action="">
                                                <div class="form-group">                                                  
                                                    <input id="absentdates" autocomplete="off" class="form-control" placeholder="Select Dates">           
                                                </div>
                                                <div class="text-center">
                                                    <input type="button" class="btn btn-primary tf-btn color margin-bottom-medium" onclick="absentNotify()" value="Submit">
                                                </div>
                                            </form>
                                        </div>
                                        <div role="tabpanel" class="tab-pane fade" id="f23">
                                            <h4>Click the button for notifying extra requirement</h4>
                                            <form action="">
                                                <div class="form-group">
                                                    <input id="extradates" autocomplete="off" class="form-control" placeholder="Select Dates">
                                                </div>
                                                <div class="text-center">
                                                    <input type="button" class="btn btn-primary tf-btn color margin-bottom-medium" onclick="extraNotify()" value="Display">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    <!-- Modal for taking reason for unavailability -->
    <div class="trans_purchase_result" id="absent-notify">
        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" onclick="absentNotifyClose()">&times;</button>
                    <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                </div>
                <div class="modal-body">
                    <h5 style="text-align:left">Reason for unavailability on <span id="absent-dates"></span></h5>
                </div>
                <div class="modal-body" id="view-details" style="display:block">
                    <input type="text" class="form-control" id="reason" name="reason" placeholder="Write your reason here..." />
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" id="view-button" onclick="absentNotification()" >View Details</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal for notifying extra requirements -->
    <div class="trans_purchase_result" id="extra-notify">
        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" onclick="extraNotifyClose()">&times;</button>
                    <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                </div>
                <div class="modal-body">
                    <h5 style="text-align:left">Actual Quantity 2 litres<span id="p-from"></span></h5>
                </div>
                <div class="modal-body" id="view-details" style="display:block">
                    <h5>Purchase Details</h5>
                    <table id="ExtraTable" class="table table-striped table-condensed table-bordered">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Extra Quantity(in litres)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>9/9/18</td>
                                <td>9</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" id="view-button" onclick="displayExtra(),extraNotification()">Submit</button>
                </div>
            </div>
        </div>
    </div>
           
            <!-- notices============================= -->
            <div id="tf-blog">
                <div class="container">
                    <!-- container -->
                    <div class="section-header">
                        <h2>Lovely <span class="highlight"><strong>Notices</strong></span></h2>
                        <h5><em></em></h5>
                        <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                    </div>
                </div>
                <div id="blog-post" class="gray-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="post-wrap">
                                    <div class="media post">
                                        <div class="media-body">
                                            <p class="small">February 14, 2018</p>

                                            <h5 class="media-heading"><strong>Milk Purity Report</strong></h5>

                                            <p>Today's milk fat content is 90%.</p>
                                        </div>
                                    </div>

                                </div>
                                <div class="post-wrap">
                                    <div class="media post">
                                        <div class="media-body">
                                            <p class="small">February 14, 2018</p>

                                            <h5 class="media-heading"><strong>Milk Purity Report</strong></h5>

                                            <p>Today's milk fat content is 81%.</p>
                                        </div>
                                    </div>


                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="post-wrap">
                                    <div class="media post">
                                        <div class="media-body">
                                            <p class="small">February 16, 2018</p>

                                            <h5 class="media-heading"><strong>Milk Purity Report</strong></h5>

                                            <p>Today's milk fat content is 90%.</p>
                                        </div>
                                    </div>


                                </div>
                                <div class="post-wrap">
                                    <div class="media post">
                                        <div class="media-body">
                                            <p class="small">February 16, 2018</p>

                                            <h5 class="media-heading"><strong>Fodder</strong></h5>

                                            <p>Changed the diet of buffaloes due to weather change.</p>
                                        </div>
                                    </div>


                                </div>

                            </div>
                        </div>
                        <div class="text-center">
                            <a href="#" class="btn btn-primary tf-btn color">Load More</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Contact
            ================================================== -->
            <div id="tf-contact">
                <div class="container">
                    <div class="section-header">
                        <h2>Feel Free to <span class="highlight"><strong>Contact Us</strong></span></h2>
                        <h5><em>We will be always with you</em></h5>
                        <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                    </div>
                </div>

                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="row">

                                <div class="col-md-4">
                                    <div class="contact-detail">
                                        <i class="fa fa-map-marker"></i>
                                        <h4> Warangal, Telangana 506002</h4> <!-- address -->
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="contact-detail">
                                        <i class="fa fa-envelope-o"></i>
                                        <h4>kamadhenudairyfarm@gmail.com</h4><!-- email  -->
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="contact-detail">
                                        <i class="fa fa-phone"></i>
                                        <h4>084152 00299</h4> <!-- phone no. -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row text-center">
                        <div class="col-md-10 col-md-offset-1">
                            <form id="contact-form" class="form" name="sentMessage" novalidate>
                                <div class="row">
                                    <!-- name -->
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <input type="text" autocomplete="off" class="form-control" placeholder="Your Name *" id="name" required data-validation-required-message="Please enter your name.">
                                            <p class="help-block text-danger"></p>
                                        </div>
                                    </div>
                                    <!-- email -->
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <!-- email input -->
                                            <input type="email" autocomplete="off" class="form-control" placeholder="Your Email *" id="email" required data-validation-required-message="Please enter your email address.">
                                            <p class="help-block text-danger"></p>
                                        </div>
                                    </div>
                                    <!-- Phone no. -->
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <!-- email input -->
                                            <input type="text" autocomplete="off" class="form-control" placeholder="Your Phone No. *" id="phone" required data-validation-required-message="Please enter your phone no.">
                                            <p class="help-block text-danger"></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- Message Text area -->
                                <div class="form-group">
                                    <textarea class="form-control" rows="7" placeholder="Tell Us Something..." id="message" required data-validation-required-message="Please enter a message."></textarea>
                                    <p class="help-block text-danger"></p>
                                    <div id="success"></div>
                                </div>
                                <button type="submit" class="btn btn-primary tf-btn color">Send Message</button>
                            </form>
                            <h2>Powered by : <span class="highlight"><strong><img src="img/fudio.png" alt="fudio"></strong></span></h2>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer
            ================================================== -->
            <div id="tf-footer">
                <div class="container">
                    <p class="pull-left">Copyright © 2018 KDF & Kamadhenu Dairy Farm. All rights reserved.</p>
                    <ul class="list-inline social pull-right">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li>

                    </ul>
                </div>
            </div>


            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
            <script type="text/javascript" src="js/jquery.1.11.1.js"></script>
            <script type="text/javascript" src="js/bootstrap.js"></script>
            <script type="text/javascript" src="js/owl.carousel.js"></script>
            <script type="text/javascript" src="js/SmoothScroll.js"></script>

            <!-- Parallax Effects -->
            <script type="text/javascript" src="js/skrollr.js"></script>
            <script type="text/javascript" src="js/imagesloaded.js"></script>
            <script type="text/javascript" src="js/jquery.isotope.js"></script>
            <script type="text/javascript" src="js/nivo-lightbox.min.js"></script>
            <script type="text/javascript" src="js/jqBootstrapValidation.js"></script>
            <script type="text/javascript" src="js/contact.js"></script>
            
            <script>
var extra=new Array();
<?php foreach($extra as $dt){?>
  extra.push("<?php echo  date_format(date_create_from_format('Y-m-d',$dt['Date']),'d-m-Y')
  ?>");
  <?php } ?>
//displayExtra(extra);
var absent=new Array();
<?php foreach($absent as $dt){?>
  absent.push("<?php echo date_format(date_create_from_format('Y-m-d',$dt['Date']),'d-m-Y')?>");
  <?php } ?>
</script>
    
    <link rel="stylesheet" type="text/css" href="css/datepickers.css" />
 <!--   <link rel="stylesheet" type="text/css" href="css/jqueryuicss.css" />      -->   
    <link href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet"/>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="https://cdn.rawgit.com/dubrox/Multiple-Dates-Picker-for-jQuery-UI/master/jquery-ui.multidatespicker.js"></script>
    <script type="text/javascript" src="js/AbsentDates.js"></script>
    <script type="text/javascript" src="js/ExtraDates.js"></script>
            <script type="text/javascript" src="js/main.js"></script>
            <script>
                $(document).ready(() => {
                    $("#view-button").click(() => {
                        // $("#summary").css("display", "none"); 
                        $("#view-details").css("display", "block");
                    })
                })
            </script>
</body>
</html>