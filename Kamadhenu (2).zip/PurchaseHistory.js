function intervalPurchase()
{
    var from =$("#purchase-from").val();
    if(from.indexOf("to")!=-1)
    {
   //     var fr = $("#purchase-from").val();
//          var to = $("#purchase-to").val();
          $("#p-from").html(from);
   //       $("#p-to").html(to);
          $("#interval-purchase").fadeIn("fast");
    $.post("purchase.php",{from:from},function(data){
        document.getElementById('table_content').innerHTML=data;
    });
    }
    else
      alert("Select Dates");
}
function monthlyPurchase()
{
    $("#monthly").fadeIn("fast");
    var month =$("#month").prop('selectedIndex');
    var monthName =$("#month").val();
    var year =$("#year").val();
    $.post("purchase.php",{month:month,year:year,monthName:monthName},function(data){
        document.getElementById('table_content_monthly').innerHTML=data;
    });
    
}