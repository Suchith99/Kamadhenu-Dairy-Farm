<?php
  include "connect.php";
  session_start();
  extract($_POST);
  if($otpInput==$_SESSION['password'])
  {
     $Id=$_SESSION['id'];
     $sql="";
     if(strcasecmp($_SESSION['type'],'Customer')==0)
     $sql = "UPDATE Customer SET password='$password' WHERE CustomerId=$Id";
     else if(strcasecmp($_SESSION['type'],'Employee')==0)
     $sql = "UPDATE Employee SET password='$password' WHERE EmployeeId=$Id";
     else
     $sql = "UPDATE Owner SET password='$password' WHERE OwnerId=$Id";
    if ($conn->query($sql) === TRUE)
    {
       echo "success";
    } 
    else
    {
       echo "failed";
    }
  }
  else
     echo "Mismatch";
  session_destroy();
  $conn->close();
?>