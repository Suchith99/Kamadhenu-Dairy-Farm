<?php
session_start();
//$_SESSION["type"]=$_GET["type"];
?>
/<?php
//extract($_GET);
?>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
<script>
function validateEmail()
{
  var email=$("#emailInput").val();
  var type=$("#type option:selected").text();
  if(email!=""&&$( "#type" ).val()!=0)
  {
  $.post("validateEmail.php",{email:email,type:type},function(response){
      alert("OK");
      if(response =="success")
      {
          //alert(response+"OK");
          $("#forgotpassword").css("display","none");
          $("#newpassword").css("display","block");
      }
      else
      {
         alert("Please enter valid Email address and select who you are");
      }
      //alert("OM");
     // alert(response);
  });
  }
  else
  {
      alert("Give valid input......");
  }
}

    function validateOTP()
{
   // var otp=<?php //echo $_SESSION['password'];?>;
   var password = $("#password").val();
   var confirmPassword = $("#confirmpassword").val();
    var otpInput=$("#otp").val();
   // if(otpInput==otp)
     // alert("OTP matched");
     if(password!=""&&otpInput!=""&&password.length>=5&&password==confirmPassword)
      {
          //alert("Password Matched");
          $.post("ChangePassword.php",{otpInput:otpInput,password:password},function(response){
              if(response=="success")
              {
                  alert("Password Changed Successfully");
                  window.location = "http://kamadhenudairy.000webhostapp.com/";
              }
              else if(response=="failed")
              {
                  alert("Couldn't Reset Password.Please try again");
                  window.location = "http://kamadhenudairy.000webhostapp.com/ResetPassword.php";
              }
              else
              {
                  alert("Invalid OTP");
                  window.location = "http://kamadhenudairy.000webhostapp.com/ResetPassword.php";
              }
          });
      }
      else
      {
          alert("Give Valid Input");
      }
}
</script>
</head>
<hr>
<div class="container">
    <div class="row">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="panel panel-default" id="forgotpassword">
                    <div class="panel-body">
                        <div class="text-center">
                          <h3><i class="fa fa-lock fa-4x"></i></h3>
                          <h2 class="text-center">Forgot Password?</h2>
                          <p>You can reset your password here.</p>
                            <div class="panel-body">
                              
                              <form class="form">
                                <fieldset>
                                  <div class="form-group">
                                    <div class="input-group">
                                      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
                                      
                                      <input id="emailInput" placeholder="email address" class="form-control" type="email" oninvalid="setCustomValidity('Please enter a valid email address!')" onchange="try{setCustomValidity('')}catch(e){}" required="">
                                      
                                    </div>
                                    <div class="form-group">
                                    <select style="margin-top:9px" class="form-control" id="type">
                                          <option disabled selected value="0"> -- Select who you are -- </option>
                                          <option>Customer</option>
                                          <option>Employee</option>
                                          <option>Owner</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    <input class="btn btn-lg btn-primary btn-block" value="Send OTP" type="button" onclick="validateEmail()">
                                  </div>
                                </fieldset>
                              </form>
                              
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default" id ="newpassword" style ="display:none;">
                    <div class="panel-body">
                        <div class="text-center">
                          <h3><i class="fa fa-lock fa-4x"></i></h3>
                          <h2 class="text-center">Reset Password</h2>
                          <p style="color:green">OTP is sent to your mail address</p>
                            <div class="panel-body">
                              
                              <form class="form">
                                <fieldset>
                                  <div class="form-group">
                                    <div class="input-group">
                                    
                                      
                                      <input id="otp" placeholder="Enter OTP" class="form-control" style="margin-top:9px" type="text" oninvalid="setCustomValidity('Please enter a valid otp!')" onchange="try{setCustomValidity('')}catch(e){}" required="">
                                      
                                    </div>
                                  <div class="form-group">
                                    <div class="input-group">
                            
                                      
                                      <input id="password" placeholder="Password" class="form-control" style="margin-top:9px" type="password" oninvalid="setCustomValidity('Please enter a valid Password!')" onchange="try{setCustomValidity('')}catch(e){}" required="">
                                      
                                    </div>
                                      <div class="form-group">
                                    <div class="input-group">
                                      
                                      <input id="confirmpassword" placeholder="Confirm Password" class="form-control" style="margin-top:9px" type="password" oninvalid="setCustomValidity('Please enter a valid confirm password!')" onchange="try{setCustomValidity('')}catch(e){}" required="">
                                      
                                    </div>
                                
                                  </div>
                                  <div class="form-group">
                                    <input class="btn btn-lg btn-primary btn-block" value="Change My Password" type="button" onclick="validateOTP()">
                                  </div>
                                </fieldset>
                              </form>
                              
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</html>
