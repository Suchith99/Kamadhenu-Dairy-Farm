<?php
ob_start();
session_start();
include  "CustomerNames.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kamadhenu Dairy Farm</title>
    <meta name="description" content="">
    <meta name="keywords" content="ace student portal">
    <meta name="author" content="fudio">

    <link rel="shortcut icon" href="img/ace1.png" type="image/x-icon">

    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.css">


    <link rel="stylesheet" href="css/nivo-lightbox.css">
    <link rel="stylesheet" href="css/nivo_lightbox_themes/default/default.css">



    <!-- Stylesheet
    ================================================== -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
    <link rel="stylesheet" type="text/css" href="css/style1.css">
    <link rel="stylesheet" type="text/css" href="css/animate1.css">

    <!-- Google Fonts
    ================================================== -->
    <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css'>

    <script type="text/javascript" src="js/modernizr.custom.js"></script>
    <script type="text/javascript" src="EnterSale.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery.1.11.1.js"></script>

    <script>
      function startLogin()
      {
        $("#single-sale").fadeIn("fast");
      }
      function closeModal()
      {
        $("#single-sale").fadeOut("fast");
      }
      function startLogin2() {
          var date = $("#saledate").val();
          $("#displaydate").html(date);
          $("#days-sale").fadeIn("fast");
          $.post("DaysOrders.php",{saledate:date},function(data){
              document.getElementById("days-orders").innerHTML=data;
          })
      }
      function viewOrders() {
          var date = $("#orderdate").val();
          $("#displayorderdate").html(date);
          $("#days-orders-modal").fadeIn("fast");
          $.post("DaysOrders.php",{orderdate:date},function(data){
              document.getElementById("days-orders-table").innerHTML=data;
          })
      }
      function closeModal2() {
          $("#days-sale").fadeOut("fast");
      }
      function closeOrdersModal() {
          $("#days-orders-modal").fadeOut("fast");
      }
    </script>

</head>
<body>
    

    <!-- Main Navigation
    ================================================== -->
    <nav id="tf-menu" class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img src="img/ace1.png" alt="..."></a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#tf-home" class="scroll">Home</a></li>
                    <li><a href="#tf-process1" class="scroll">Sales</a></li>
                    <li><a href="#tf-works" class="scroll">Orders</a></li>
                    <li><a href="#tf-blog" class="scroll">Notices</a></li>
                    <li><a href="#tf-contact" class="scroll">Contact us</a></li>
                    <li><a href ="Logout.php" style="color:blue">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Home Section
    ================================================== -->
    <div id="tf-home">
        <div class="overlay">
            <div class="container">
                <div class="content-heading text-center">
                    <h1>Kamadhenu Dairy Farm</h1>
                    <p class="lead">...where purity is met</p>
                    <a href="#" class="scroll goto-btn text-uppercase">Welcome <?php echo $_SESSION['Name']; ?></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Intro Section
    ================================================== -->
    <div id="tf-intro">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <img src="img/logo-w.png" class="intro-logo img-responsive" alt="sssuu">
                    <p>Kamadhenu Dairy Farm is established with the motive to provide pure milk to the people of Warangal.</p>
                </div>

            </div>
        </div>
    </div>



    <!-- my info pillagada
    ================================================== -->
    <div id="tf-process1">
        <div id="tf-features">
            <div class="container">
                <div class="section-header">
                    <h2>Enter<span class="highlight"><strong>Sales</strong></span></h2>
                    <h5><em>Have a smile</em></h5>
                    <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                </div>
            </div>
            <div id="feature" class="gray-bg">
                <div class="container">
                    <div class="row" role="tabpanel">
                        <div class="col-md-4 col-md-offset-1">
                            <ul class="features nav nav-pills nav-stacked" role="tablist">
                                <li role="presentation" class="active">
                                    <a href="#f1" aria-controls="f1" role="tab" data-toggle="tab">
                                        <span class="fa fa-pencil"></span>
                                        Single Sale<br><small></small>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#f2" aria-controls="f2" role="tab" data-toggle="tab">
                                        <span class="fa fa-pencil"></span>
                                        Day's Sale<br><small></small>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-6">

                            <div class="tab-content features-content">
                                <div role="tabpanel" class="tab-pane fade in active" id="f1">
                                    <h4>Select Customer and Quantity</h4>
                                    <form id="CustomerSingleSaleForm">
                                        <div class="form-group">
                                            <!-- Customer -->
                                                <label for="customer">Customer</label>
                                                <select class="form-control"  id="customer" name="customer">
                                                <option disabled selected value> -- Select a Customer -- </option>
                                                <?php foreach ( $rows as $option ) : ?>
                                                <option value="<?php echo $option['CustomerID']; ?>"><?php echo $option['Name']; ?></option>
                                                <?php endforeach; ?>
                                                </select>          
                                        </div>
                                        <div class="form-group">
                                            <label for="quant">Quantity</label>
                                            <input type="text" autocomplete="off" class="form-control" id="quant" name="quant">
                                        </div>
                                        <div class="form-group">
                                            <!-- Date -->
                                            <label for="to">Date</label>
                                            <input type="date"  autocomplete="off" class="form-control" id="to" name="to">
                                        </div>
                                        <div class="text-center">
                                            <input type="button" class="btn btn-primary tf-btn color margin-bottom-medium" value="Submit" onclick="startLogin(),confirmSale()">
                                        </div>
                                  </div>
                                </form>
                                <div role="tabpanel" class="tab-pane fade" id="f2">
                                    <form id="DaysSaleForm">
                                     <div class="form-group">
                                        <!-- Date -->
                                        <label for="to">Date</label>
                                        <input type="date" date-date-format="dd mm yyyy" autocomplete="off" class="form-control" id="saledate" name="saledate">
                                     </div>
                                     <div class="text-center">
                                        <input type="button" class="btn btn-primary tf-btn color margin-bottom-medium" value="Enter" onclick="startLogin2()">
                                     </div>
                                    </form>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <!--Modal to display results-->
    <div class="trans_purchase_result" id="single-sale">   
            <div class="modal-dialog modal-lg">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" onclick="closeModal()">&times;</button>
                        <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                    </div>
                    <div class="modal-body" id="summary">
                        <h5 style="text-align:left">Sale Details</h5>
                    </div>
                    <div class="modal-body" id="view-details">
                        <table id="singleSaleTable" class="table table-striped table-condensed table-bordered">
                            <thead>
                                <tr>
                                <th>Name</th>
                                <th>Quantity(in litres)</th>
                                <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Ganesh</td>
                                    <td>9</td>
                                    <td>9/9/18</td>                                    
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal" id="view-button" onClick="singleSale()">Confirm</button>
                    </div>
                </div>
            </div>
    </div>

    <div class="trans_purchase_result" id="days-sale">
        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" onclick="closeModal2()">&times;</button>
                    <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                </div>
                <div class="modal-body" id="summary">
                    <h5 style="text-align:center">Sales of <span id="displaydate"></span> </h5>
                </div>
                <div class="modal-body" id="days-orders" >
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" id="view-button" onClick="daySale()">Confirm</button>
                </div>
            </div>
        </div>
    </div>
            <!-- Payments Section
               ================================================== -->
            <div id="tf-works">
                <div id="tf-features">
                    <div class="container">
                        <div class="section-header">
                            <h2>Orders<span class="highlight"><strong>INFO</strong></span></h2>
                            <h5><em>Have a smile</em></h5>
                            <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                        </div>
                    </div>
                    <div id="feature" class="gray-bg">
                        <div class="container">
                            <div class="row" role="tabpanel">
                                <div class="col-md-4 col-md-offset-1">
                                    <ul class="features nav nav-pills nav-stacked" role="tablist">
                                        <li role="presentation" class="active">
                                            <a href="#f11" aria-controls="f11" role="tab" data-toggle="tab">
                                                <span class="fa fa-pencil"></span>
                                                Days Orders<br><small></small>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <div class="tab-content features-content">
                                        <div role="tabpanel" class="tab-pane fade in active" id="f11">
                                            <h4>Select date to view Orders</h4>
                                                <div class="form-group">
                                                    <!-- From Date -->
                                                    <label for="orderdate">Date</label>
                                                    <input type="date" autocomplete="off" class="form-control" id="orderdate" name="orderdate">
                                                </div>
                                                <div class="text-center">
                                                    <input type="submit" class="btn btn-primary tf-btn color margin-bottom-medium" value="View" onclick="viewOrders()">
                                                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           
           
    <div class="trans_purchase_result" id="days-orders-modal">
        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" onclick="closeOrdersModal()">&times;</button>
                    <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                </div>
                <div class="modal-body" id="summary">
                    <h5 style="text-align:center">Orders of <span id="displayorderdate"></span> </h5>
                </div>
                <div class="modal-body" id="days-orders-table" >
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" id="view-button" onClick="closeOrdersModal()">Close</button>
                </div>
            </div>
        </div>
    </div>
            <!-- news
            ================================================== -->
           
            <!-- notices============================= -->
            <div id="tf-blog">
                <div class="container">
                    <!-- container -->
                    <div class="section-header">
                        <h2>Lovely <span class="highlight"><strong>Notices</strong></span></h2>
                        <h5><em></em></h5>
                        <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                    </div>
                </div>
                <div id="blog-post" class="gray-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="post-wrap">
                                    <div class="media post">
                                        <div class="media-body">
                                            <p class="small">February 14, 2018</p>

                                            <h5 class="media-heading"><strong>Milk Purity Report</strong></h5>

                                            <p>Today's milk fat content is 90%.</p>
                                        </div>
                                    </div>

                                </div>
                                <div class="post-wrap">
                                    <div class="media post">
                                        <div class="media-body">
                                            <p class="small">February 14, 2018</p>

                                            <h5 class="media-heading"><strong>Milk Purity Report</strong></h5>

                                            <p>Today's milk fat content is 81%.</p>
                                        </div>
                                    </div>


                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="post-wrap">
                                    <div class="media post">
                                        <div class="media-body">
                                            <p class="small">February 16, 2018</p>

                                            <h5 class="media-heading"><strong>Milk Purity Report</strong></h5>

                                            <p>Today's milk fat content is 90%.</p>
                                        </div>
                                    </div>


                                </div>
                                <div class="post-wrap">
                                    <div class="media post">
                                        <div class="media-body">
                                            <p class="small">February 16, 2018</p>

                                            <h5 class="media-heading"><strong>Fodder</strong></h5>

                                            <p>Changed the diet of buffaloes due to weather change.</p>
                                        </div>
                                    </div>


                                </div>

                            </div>
                        </div>
                        <div class="text-center">
                            <a href="#" class="btn btn-primary tf-btn color">Load More</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Contact
            ================================================== -->
            <div id="tf-contact">
                <div class="container">
                    <div class="section-header">
                        <h2>Feel Free to <span class="highlight"><strong>Contact Us</strong></span></h2>
                        <h5><em>We will be always with you</em></h5>
                        <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                    </div>
                </div>

                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="row">

                                <div class="col-md-4">
                                    <div class="contact-detail">
                                        <i class="fa fa-map-marker"></i>
                                        <h4> Warangal, Telangana 506002</h4> <!-- address -->
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="contact-detail">
                                        <i class="fa fa-envelope-o"></i>
                                        <h4>kamadhenudairyfarm@gmail.com</h4><!-- email  -->
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="contact-detail">
                                        <i class="fa fa-phone"></i>
                                        <h4>084152 00299</h4> <!-- phone no. -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <h2 class="text-center">Powered by : <span class="highlight"><strong><img src="img/fudio.png" alt="fudio"></strong></span></h2>
                </div>
            </div>
            <!-- Footer
            ================================================== -->
            <div id="tf-footer">
                <div class="container">
                    <p class="pull-left">Copyright � 2018 KDF & Kamadhenu Dairy Farm. All rights reserved.</p>
                    <ul class="list-inline social pull-right">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li>

                    </ul>
                </div>
            </div>


            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
            <script type="text/javascript" src="js/jquery.1.11.1.js"></script>
            <script type="text/javascript" src="js/bootstrap.js"></script>
            <script type="text/javascript" src="js/owl.carousel.js"></script>
            <script type="text/javascript" src="js/SmoothScroll.js"></script>

            <!-- Parallax Effects -->
            <script type="text/javascript" src="js/skrollr.js"></script>
            <script type="text/javascript" src="js/imagesloaded.js"></script>
            <script type="text/javascript" src="js/jquery.isotope.js"></script>
            <script type="text/javascript" src="js/nivo-lightbox.min.js"></script>
            <script type="text/javascript" src="js/jqBootstrapValidation.js"></script>
            
            
   
    
            <script type="text/javascript" src="js/main.js"></script>
</body>
</html>