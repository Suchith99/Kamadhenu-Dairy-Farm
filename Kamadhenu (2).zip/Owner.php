<?php
ob_start();
session_start();
include "MilkType.php";
include "CustomerNames.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kamadhenu Dairy Farm</title>
    <meta name="description" content="">
    <meta name="keywords" content="ace student portal">
    <meta name="author" content="fudio">

    <link rel="shortcut icon" href="img/ace1.png" type="image/x-icon">

    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.css">


    <link rel="stylesheet" href="css/nivo-lightbox.css">
    <link rel="stylesheet" href="css/nivo_lightbox_themes/default/default.css">



    <!-- Stylesheet
    ================================================== -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
    <link rel="stylesheet" type="text/css" href="css/style1.css">
    <link rel="stylesheet" type="text/css" href="css/animate1.css">

    <!-- Google Fonts
    ================================================== -->
    <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css'>

    <script type="text/javascript" src="js/modernizr.custom.js"></script>
    <script type="text/javascript" src="EnterRegister.js"></script>
    <script type="text/javascript" src="EnterPayment.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery.1.11.1.js"></script>

    <script>
      function closeCustomer()
      {
        $("#CustomerForm").fadeOut("fast");
      }
      function startLogin2() {
          var date = $("#saledate").val();
          $("#displaydate").html(date);
          $("#days-sale").fadeIn("fast");
          $.post("DaysOrders.php",{saledate:date},function(data){
              document.getElementById("days-orders").innerHTML=data;
          })
      }
      function closeEmployeeForm() {
          $("#EmployeeForm").fadeOut("fast");
      }
      function openPaymentConfirmation() {
          $("#single-payment").fadeIn("fast");
      }
      function closePaymentConfirmation() {
          $("#single-payment").fadeOut("fast");
      }
      function closeDueList() {
          $("#due-list").fadeOut("fast");
      }
    </script>

</head>
<body>
    

    <!-- Main Navigation
    ================================================== -->
    <nav id="tf-menu" class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"><img src="img/ace1.png" alt="..."></a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#tf-home" class="scroll">Home</a></li>
                    <li><a href="#tf-process1" class="scroll">Register</a></li>
                    <li><a href="#tf-works" class="scroll">Payments</a></li>
                    <li><a href="#tf-process" class="scroll">Reports</a></li>
                    <li><a href="#tf-blog" class="scroll">Notices</a></li>
                    <li><a href="#tf-contact" class="scroll">Contact us</a></li>
                    <li><a href ="Logout.php" style="color:blue">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Home Section
    ================================================== -->
    <div id="tf-home">
        <div class="overlay">
            <div class="container">
                <div class="content-heading text-center">
                    <h1>Kamadhenu Dairy Farm</h1>
                    <p class="lead">...where purity is met</p>
                    <a href="#" class="scroll goto-btn text-uppercase">Welcome <?php echo $_SESSION['Name']; ?></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Intro Section
    ================================================== -->
    <div id="tf-intro">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <img src="img/logo-w.png" class="intro-logo img-responsive" alt="sssuu">
                    <p>Kamadhenu Dairy Farm is established with the motive to provide pure milk to the people of Warangal.</p>
                </div>

            </div>
        </div>
    </div>



    <!-- my info pillagada
    ================================================== -->
    <div id="tf-process1">
        <div id="tf-features">
            <div class="container">
                <div class="section-header">
                    <h2>New<span class="highlight"><strong>Registration</strong></span></h2>
                    <h5><em>Have a smile</em></h5>
                    <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                </div>
            </div>
            <div id="feature" class="gray-bg">
                <div class="container">
                    <div class="row" role="tabpanel">
                        <div class="col-md-4 col-md-offset-1">
                            <ul class="features nav nav-pills nav-stacked" role="tablist">
                                <li role="presentation" class="active">
                                    <a href="#f1" aria-controls="f1" role="tab" data-toggle="tab">
                                        <span class="fa fa-pencil"></span>
                                        Customer<br><small></small>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#f2" aria-controls="f2" role="tab" data-toggle="tab">
                                        <span class="fa fa-pencil"></span>
                                        Employee<br><small></small>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-6">

                            <div class="tab-content features-content">
                                <!-- Customer -->
                                <div role="tabpanel" class="tab-pane fade in active" id="f1">
                                    <h4>Customer Registeration</h4>
                                        <div class="form-group">
                                            <input type="button" class="form-control" value="Register" id="CustomerRegister" onclick="document.getElementById('CustomerForm').style.display='block'" >
                                        </div>
                                </div>
                                <!-- Employee -->
                                <div role="tabpanel" class="tab-pane fade" id="f2">
                                    <div class="form-group">
                                       <h4>Employee Registeration</h4>
                                         <div class="form-group">
                                            <input type="button" class="form-control" value="Register" id="EmployeeRegister" onclick="document.getElementById('EmployeeForm').style.display='block'">
                                         </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   </div>

    <!--Modal to display results-->
    <div class="registrationform" id="CustomerForm">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">  
           <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" onclick="closeCustomer()">&times;</button>
                    <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                </div>
                <div class="modal-body" id="summary">
                    <h5 style="text-align:center">Customer Registeration Form<span id="displaydate"></span> </h5>
                    <form class="form" id="CustomerRegistrationForm">
                      <label for="newCustomerName">Customer Name</label> 
                      <input type="text" class="form-control" id="newCustomerName" name="newCustomerName" placeholder="Enter Customer Name" onblur= "validateName()">
                      <p id="Nameauthentication" style="color:red"></p>
                      <label for="Milk">Milk Cost</label>
                      <select name="Milk" id="Milk" class="form-control">
                      <option disabled selected value> -- Select Milk Cost -- </option>
                      <?php foreach ( $milktype as $option ) : ?>
                      <option value="<?php echo $option['MilkID']; ?>"><?php echo $option['Cost']." - ".$option['Description']; ?></option>
                      <?php endforeach; ?>
                      </select>
                      <label for="DailyQuantity">Quantity Required(per day)</label>
                      <input type="number" class="form-control" id="DailyQuantity" name="DailyQuantity">
                      <label for="Address">Address</label>
                      <input type="text" class="form-control" id="Address" name="Address" placeholder="Line 1">
                      <input type="text" class="form-control" id="Line2" name="Line2" placeholder="Line 2(Optional)">
                      <label for="city">City</label>
                      <select name="city" id="city" class="form-control">
                          <option disabled selected value> -- Select city --</option>
                          <option value="Warangal">Warangal</option>
                          <option value="Hanmakonda">Hanmakonda</option>
                          <option value="Kazipet">Kazipet</option>
                      </select>
                      <label for="ZIP">Pincode</label>
                      <input type="number" class="form-control" id="ZIP" name="ZIP" placeholder="Enter Postal Code">
                      <label for="mobile">Mobile Number</label>
                      <input type="text" class="form-control" id="mobile" name="mobile" onkeypress= "validatePhone()">
                      <p id="mobileauthentication" style="color:red"></p>
                      <label for="CustomerEmail">E-mail</label>
                      <input type="email" class="form-control" id="CustomerEmail" name="CustomerEmail" onkeypress= "validateEmail()">
                      <p id="emailauthentication" style="color:red"></p>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" id="view-button" onClick="customerRegister()">Confirm</button>
                </div>
            </div>
       </div>
   </div>
    <div class="registrationform" id="EmployeeForm">
        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" onclick="closeEmployeeForm()">&times;</button>
                    <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                </div>
                <div class="modal-body" id="summary">
                    <h5 style="text-align:center">Employee Registration Form</h5>
                      <form class="form" id="EmployeeRegistrationForm">
                      <label for="newEmployeeName">Employee Name</label> 
                      <input type="text" class="form-control" id="newEmployeeName" name="newEmployeeName" placeholder="Enter Employee Name" onblur= "EvalidateName()">
                      <p id="ENameauthentication" style="color:red"></p>
                      <label for="Salary">Salary(per month)</label>
                      <input type="number" class="form-control" id="Salary" name="Salary">
                      <label for="DOJ">Date of Joining</label>
                      <input type="date" class="form-control" id="DOJ" name="DOJ">
                      <label for="EAddress">Address</label>
                      <input type="text" class="form-control" id="EAddress" name="EAddress" placeholder="Line 1">
                      <input type="text" class="form-control" id="ELine2" name="ELine2" placeholder="Line 2(Optional)">
                      <label for="Ecity">City</label>
                      <select name="Ecity" id="Ecity" class="form-control">
                          <option disabled selected value> -- Select city --</option>
                          <option value="Warangal">Warangal</option>
                          <option value="Hanmakonda">Hanmakonda</option>
                          <option value="Kazipet">Kazipet</option>
                      </select>
                      <label for="EZIP">Pincode</label>
                      <input type="number" class="form-control" id="EZIP" name="EZIP" placeholder="Enter Postal Code">
                      <label for="Emobile">Mobile Number</label>
                      <input type="text" class="form-control" id="Emobile" name="Emobile" onkeypress= "EvalidatePhone()">
                      <p id="Emobileauthentication" style="color:red"></p>
                      <label for="EmployeeEmail">E-mail</label>
                      <input type="email" class="form-control" id="EmployeeEmail" name="EmployeeEmail" onkeypress= "EvalidateEmail()">
                      <p id="Eemailauthentication" style="color:red"></p>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" id="view-button" onClick="employeeRegister()">Confirm</button>
                </div>
            </div>
        </div>
    </div>
            <!-- Payments Section
               ================================================== -->
            <div id="tf-works">
                <div id="tf-features">
                    <div class="container">
                        <div class="section-header">
                            <h2>Payments<span class="highlight"><strong>INFO</strong></span></h2>
                            <h5><em>Have a smile</em></h5>
                            <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                        </div>
                    </div>
                    <div id="feature" class="gray-bg">
                        <div class="container">
                            <div class="row" role="tabpanel">
                                <div class="col-md-4 col-md-offset-1">
                                    <ul class="features nav nav-pills nav-stacked" role="tablist">
                                        <li role="presentation" class="active">
                                            <a href="#f11" aria-controls="f11" role="tab" data-toggle="tab">
                                                <span class="fa fa-pencil"></span>
                                                Recieve Payments<br><small></small>
                                            </a>
                                        </li>
                                        <li role="presentation">
                                            <a href="#f22" aria-controls="f22" role="tab" data-toggle="tab">
                                                <span class="fa fa-pencil"></span>
                                               Check Dues<br><small></small>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <div class="tab-content features-content">
                                        <div role="tabpanel" class="tab-pane fade in active" id="f11">
                                          <h4>Select Customer and Amount</h4>
                                          <form id="CustomerSinglePaymentForm">
                                          <div class="form-group">
                                            <!-- Customer -->
                                                <label for="payingcustomer">Customer</label>
                                                <select class="form-control"  id="payingcustomer" name="payingcustomer">
                                                <option disabled selected value> -- Select a Customer -- </option>
                                                <?php foreach ( $rows as $option ) : ?>
                                                <option value="<?php echo $option['CustomerID']; ?>"><?php echo $option['Name']; ?></option>
                                                <?php endforeach; ?>
                                                </select>          
                                          </div>
                                          <div class="form-group">
                                            <label for="paying">Amount</label>
                                            <input type="text" autocomplete="off" class="form-control" id="paying" name="paying">
                                          </div>
                                          <div class="form-group">
                                            <!-- Date -->
                                            <label for="paidon">Date</label>
                                            <input type="date"  autocomplete="off" class="form-control" id="paidon" name="paidon">
                                          </div>
                                          <div class="text-center">
                                            <input type="button" class="btn btn-primary tf-btn color margin-bottom-medium" value="Submit" onclick="openPaymentConfirmation(), confirmPayment()">
                                          </div>
                                          </form>
                                      </div>
                                      <div role="tabpanel" class="tab-pane fade" id="f22">
                                            <h4>Click the button to check dues</h4>
                                            <form >
                                                <div class="text-center">
                                                    <input type="button" class="btn btn-primary tf-btn color margin-bottom-medium" onclick="checkDues()" value="Check">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!--Modal to display results-->
    <div class="trans_purchase_result" id="single-payment">   
            <div class="modal-dialog modal-lg">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" onclick="closePaymentConfirmation()">&times;</button>
                        <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                    </div>
                    <div class="modal-body" id="summary">
                        <h5 style="text-align:left">Payment Details</h5>
                    </div>
                    <div class="modal-body" id="view-details">
                        <table id="singlePaymentTable" class="table table-striped table-condensed table-bordered">
                            <thead>
                                <tr>
                                <th>Name</th>
                                <th>Amount</th>
                                <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Ganesh</td>
                                    <td>9</td>
                                    <td>9/9/18</td>                                    
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal" id="view-button" onClick="singlePayment()">Confirm</button>
                    </div>
                </div>
            </div>
    </div>
    
    <div class="trans_purchase_result" id="due-list">   
            <div class="modal-dialog modal-lg">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" onclick="closeDueList()">&times;</button>
                        <h4 class="modal-title">Kamadhenu Dairy Farm</h4>
                    </div>
                    <div class="modal-body" id="summary">
                        <h5 style="text-align:left">Due Details</h5>
                    </div>
                    <div class="modal-body" id="due-details">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal" id="view-button" onClick="closeDueList()">Close</button>
                    </div>
                </div>
            </div>
    </div>
           
            <!-- news
            ================================================== -->
            <div id="tf-process">
                <div id="tf-features">
                    <div class="container">
                        <div class="section-header">
                            <h2>Notify<span class="highlight"><strong>Us</strong></span></h2>
                            <h5><em>Have a smile</em></h5>
                            <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                        </div>
                    </div>
                    <div id="feature" class="gray-bg">
                        <div class="container">
                            <div class="row" role="tabpanel">
                                <div class="col-md-4 col-md-offset-1">
                                    <ul class="features nav nav-pills nav-stacked" role="tablist">
                                        <li role="presentation" class="active">
                                            <a href="#f13" aria-controls="f13" role="tab" data-toggle="tab">
                                                <span class="fa fa-pencil"></span>
                                                Absent Note<br><small></small>
                                            </a>
                                        </li>
                                        <li role="presentation">
                                            <a href="#f23" aria-controls="f23" role="tab" data-toggle="tab">
                                                <span class="fa fa-pencil"></span>
                                                Extra Note<br><small></small>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <div class="tab-content features-content">
                                        <div role="tabpanel" class="tab-pane fade in active" id="f13">
                                            <h4>Enter from and to dates</h4>
                                            <form action="">
                                                <div class="form-group">
                                                    <div id="print-array" style="position:relative"></div>
                                                    <input id="datepicker" class="multidatepicker form-control" placeholder="dd-mm-yy">             
                                                </div>
                                                <div class="text-center">
                                                    <input type="submit" class="btn btn-primary tf-btn color margin-bottom-medium" value="Submit">
                                                </div>
                                            </form>
                                        </div>
                                        <div role="tabpanel" class="tab-pane fade" id="f23">
                                            <h4>Click the button for notifying</h4>
                                            <form action="">
                                                <div class="text-center">
                                                    <input type="submit" class="btn btn-primary tf-btn color margin-bottom-medium" value="Display">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           
            <!-- notices============================= -->
            <div id="tf-blog">
                <div class="container">
                    <!-- container -->
                    <div class="section-header">
                        <h2>Lovely <span class="highlight"><strong>Notices</strong></span></h2>
                        <h5><em></em></h5>
                        <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                    </div>
                </div>
                <div id="blog-post" class="gray-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="post-wrap">
                                    <div class="media post">
                                        <div class="media-body">
                                            <p class="small">February 14, 2018</p>

                                            <h5 class="media-heading"><strong>Milk Purity Report</strong></h5>

                                            <p>Today's milk fat content is 90%.</p>
                                        </div>
                                    </div>

                                </div>
                                <div class="post-wrap">
                                    <div class="media post">
                                        <div class="media-body">
                                            <p class="small">February 14, 2018</p>

                                            <h5 class="media-heading"><strong>Milk Purity Report</strong></h5>

                                            <p>Today's milk fat content is 81%.</p>
                                        </div>
                                    </div>


                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="post-wrap">
                                    <div class="media post">
                                        <div class="media-body">
                                            <p class="small">February 16, 2018</p>

                                            <h5 class="media-heading"><strong>Milk Purity Report</strong></h5>

                                            <p>Today's milk fat content is 90%.</p>
                                        </div>
                                    </div>


                                </div>
                                <div class="post-wrap">
                                    <div class="media post">
                                        <div class="media-body">
                                            <p class="small">February 16, 2018</p>

                                            <h5 class="media-heading"><strong>Fodder</strong></h5>

                                            <p>Changed the diet of buffaloes due to weather change.</p>
                                        </div>
                                    </div>


                                </div>

                            </div>
                        </div>
                        <div class="text-center">
                            <a href="#" class="btn btn-primary tf-btn color">Load More</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Contact
            ================================================== -->
            <div id="tf-contact">
                <div class="container">
                    <div class="section-header">
                        <h2>Feel Free to <span class="highlight"><strong>Contact Us</strong></span></h2>
                        <h5><em>We will be always with you</em></h5>
                        <div class="fancy"><span><img src="img/favicon.png" alt="..."></span></div>
                    </div>
                </div>

                <div class="container">
                    <div class="row">
                        <div class="col-md-10 col-md-offset-1">
                            <div class="row">

                                <div class="col-md-4">
                                    <div class="contact-detail">
                                        <i class="fa fa-map-marker"></i>
                                        <h4> Warangal, Telangana 506002</h4> <!-- address -->
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="contact-detail">
                                        <i class="fa fa-envelope-o"></i>
                                        <h4>kamadhenudairyfarm@gmail.com</h4><!-- email  -->
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="contact-detail">
                                        <i class="fa fa-phone"></i>
                                        <h4>084152 00299</h4> <!-- phone no. -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
         <!--           <div class="row text-center">
                        <div class="col-md-10 col-md-offset-1">
                            <form id="contact-form" class="form" name="sentMessage" novalidate>
                                <div class="row">
                                    <!-- name -->
         <!--                           <div class="col-md-4">
                                        <div class="form-group">
                                            <input type="text" autocomplete="off" class="form-control" placeholder="Your Name *" id="name" required data-validation-required-message="Please enter your name.">
                                            <p class="help-block text-danger"></p>
                                        </div>
                                    </div>
                                    <!-- email -->
         <!--                           <div class="col-md-4">
                                        <div class="form-group">
                                            <!-- email input -->
        <!--                                     <input type="email" autocomplete="off" class="form-control" placeholder="Your Email *" id="email" required data-validation-required-message="Please enter your email address.">
                                            <p class="help-block text-danger"></p>
                                        </div>
                                    </div>
                                    <!-- Phone no. -->
          <!--                          <div class="col-md-4">
                                        <div class="form-group">
                                            <!-- email input -->
          <!--                                  <input type="text" autocomplete="off" class="form-control" placeholder="Your Phone No. *" id="phone" required data-validation-required-message="Please enter your phone no.">
                                            <p class="help-block text-danger"></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- Message Text area -->
          <!--                      <div class="form-group">
                                    <textarea class="form-control" rows="7" placeholder="Tell Us Something..." id="message" required data-validation-required-message="Please enter a message."></textarea>
                                    <p class="help-block text-danger"></p>
                                    <div id="success"></div>
                                </div>
                                <button type="submit" class="btn btn-primary tf-btn color">Send Message</button>
                            </form>
                            <h2>Powered by : <span class="highlight"><strong><img src="img/fudio.png" alt="fudio"></strong></span></h2>
                        </div>
                    </div>  -->
                    <h2 class="text-center">Powered by : <span class="highlight"><strong><img src="img/fudio.png" alt="fudio"></strong></span></h2>
                </div>
            </div>
            <!-- Footer
            ================================================== -->
            <div id="tf-footer">
                <div class="container">
                    <p class="pull-left">Copyright � 2018 KDF & Kamadhenu Dairy Farm. All rights reserved.</p>
                    <ul class="list-inline social pull-right">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li>

                    </ul>
                </div>
            </div>


            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
            <script type="text/javascript" src="js/jquery.1.11.1.js"></script>
            <script type="text/javascript" src="js/bootstrap.js"></script>
            <script type="text/javascript" src="js/owl.carousel.js"></script>
            <script type="text/javascript" src="js/SmoothScroll.js"></script>

            <!-- Parallax Effects -->
            <script type="text/javascript" src="js/skrollr.js"></script>
            <script type="text/javascript" src="js/imagesloaded.js"></script>
            <script type="text/javascript" src="js/jquery.isotope.js"></script>
            <script type="text/javascript" src="js/nivo-lightbox.min.js"></script>
            <script type="text/javascript" src="js/jqBootstrapValidation.js"></script>
            
            
    
            <script type="text/javascript" src="js/main.js"></script>
       <!--     <script>
                $(document).ready(() => {
                    $("#view-button").click(() => {
                        // $("#summary").css("display", "none"); 
                        $("#view-details").css("display", "block");
                    })
                })
            </script> -->
</body>
</html>