<?php
include "connect.php";
session_start();
extract($_POST);
$userId =$_SESSION["userId"];
echo "Om";
if(isset($_REQUEST['reason']))
{
    $absentDates=$dates;
    $dates =explode(" , ",$absentDates);
    for($i=0;$i<count($dates);$i++)
    {
      $formatteddates=date_format(date_create_from_format('d-m-Y',$dates[$i]),'Y-m-d');
      $stmt = $conn->prepare("INSERT INTO Absent (CustomerID, Date, Reason) VALUES (?, ?, ?)");
      $stmt->bind_param("iss", $userId, $formatteddates, $reason);
      $stmt->execute();
    }
}
else
{
    $extraDate = $date;
    $formattedDate = date_format(date_create_from_format('d-m-Y',$extraDate),'Y-m-d');
    $stmt = $conn->prepare("Insert into Extra (CustomerID, Date, Quantity) Values (?, ?, ?)");
    $stmt->bind_param("iss",$userId, $formattedDate, $quantity);
    $stmt->execute();
}



?>
