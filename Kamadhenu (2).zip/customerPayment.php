<?php
include "connect.php";
session_start();
extract($_POST);
$result="";
$userId =$_SESSION["userId"];
if(isset($_REQUEST['from']))
{
    $purchase_from=$_POST["from"];
    $dateArr =explode(" to ",$purchase_from);
    $dateArr[0]=date_format(date_create_from_format('d-m-Y',$dateArr[0]),'Y-m-d');
    $dateArr[1]=date_format(date_create_from_format('d-m-Y',$dateArr[1]),'Y-m-d');
        $query="SELECT Date, Amount FROM Payment where CustomerId =$userId and date between '".$dateArr[0]."' and '".$dateArr[1]."'";
        $stmt = mysqli_query($conn,$query);
    $result= "<table id='classTable' class='table table-striped table-condensed table-bordered'><thead><tr><th>Date</th><th>Amount</th></tr></thead>";
   while($row = mysqli_fetch_assoc($stmt)) 
   {
    $result.= "<tr><td>".$row['Date']."</td><td>".$row['Amount']."</td></tr>";
   }
   echo $result."</table>";
}
else
{
    $MilkQuery="SELECT MilkID FROM Customer where CustomerID =$userId";
    $stmt1 = mysqli_query($conn,$MilkQuery);
    while($row = mysqli_fetch_assoc($stmt1)) 
    {
       $Milk= $row['MilkID'];
    }

    $AmountQuery="SELECT ifnull(Sum(Amount),0) as Paid  FROM Payment where CustomerID =$userId";
    $stmt = mysqli_query($conn,$AmountQuery);
    $QuantityQuery="SELECT ifnull(Sum(Quantity),0) as Quant FROM Sale where CustomerID =$userId";
    $stmt2 = mysqli_query($conn,$QuantityQuery);
    $Paid=0;
    while($row = mysqli_fetch_assoc($stmt)) 
    {
       $Paid= $row['Paid'];
    }
    while($row= mysqli_fetch_assoc($stmt2))
    {
       $Quantity= $row['Quant'];
    }
    $BillQuery="Select Cost,$Quantity*Cost as Bill from Milk where MilkID=$Milk";
    $stmt3 = mysqli_query($conn,$BillQuery);
    $Bill=0;
    while($row = mysqli_fetch_assoc($stmt3))
    {
       $Bill=$row['Bill'];
       $Cost=$row['Cost'];
    }
    $Due=$Bill-$Paid;
 //   if($Quantity!=0)
  //  $Cost=$Bill/$Quantity;
    if($Paid==null)
        $Paid=0;
    $BillTable= "<table class='table table-condensed'><tbody><tr><td>Purchased </td><td>$Quantity litres</td></tr><tr><td>Cost per litre is</td><td>Rs.$Cost/-</td></tr><tr><td> Paid</td><td>Rs.$Paid/-</td></tr></tbody>";
    if($Due<0)
    {
      $BillTable.="<tr><th>Balance amount is </th><th>".(-$Due)."/-</th></tr>";
    }
    else if($Due>0)
    {
      $BillTable.="<tr><th>Amount Due is</th><th>Rs.".$Due."/-</th></tr>";
      $BillTable.="<tr><th>Enter Amount you wish to pay</th><th><input type='number' id='Amount' name='Amount'></th></tr>";
      $BillTable.="<tr><th></th><th><input type='button' onClick='proceedtopay()' value='Proceed to Pay'></th></tr>";
    }
    echo $BillTable."</table>";
}


//echo $result."</table>";
?>