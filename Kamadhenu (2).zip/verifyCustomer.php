<?php
ob_start();
 session_start();
 require "connect.php";
 extract($_POST);

    $flag=false;
    $result = $conn->query("SELECT * FROM `Customer`");
    $rows = $result->fetch_all(MYSQLI_ASSOC);
    foreach($rows as $row)
    {
        if($row['Email']==$Customername&&$row['Password']==$Customerpassword)
        {
            $_SESSION['userId'] = $row['CustomerID']; 
            $_SESSION['Name'] = $row['Name'];
            $flag=true;
            echo $flag;
        }
    }
    if(!$flag)
    {
                    echo $flag;

        //echo "<script>alert('Invalid Credentials')</script>";
    }
 
?>