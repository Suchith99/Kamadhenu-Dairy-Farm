<?php
 include "connect.php";
 extract($_POST);
    if(isset($_REQUEST['quant']))
    {
      $stmt = $conn->prepare("INSERT INTO Sale (CustomerID, Date, Quantity) VALUES (?, ?, ?)");
      $stmt->bind_param("iss", $customer, $to, $quant);
      if($stmt->execute())
        echo "Successfully Entered !";
      else
        echo "Try Again";
    }
    else
    {
      if(!empty($_POST['Customer']))
      {
        $stmt = $conn->prepare("INSERT INTO Sale (CustomerID, Date, Quantity) VALUES (?, ?, ?)");
        // Loop to store and display values of individual checked checkbox.
        $flag=true;
        for($i=0;$i<count($Customer);$i++)
        {
           $stmt->bind_param("iss", $Customer[$i], $saledate, $Quantity[$i]);
           if(!$stmt->execute())
             $flag=false;
        }
        if($flag)
          echo "Successfully entered days sale";
        else
          echo "Try Again";
      }
      else
         echo "Mark the customers to whom you delivered ";
    }
?>