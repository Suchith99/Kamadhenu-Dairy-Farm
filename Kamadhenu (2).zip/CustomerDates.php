<?php
    include "connect.php";
    $userId =$_SESSION["userId"];
    $result = $conn->query("SELECT Date FROM `Absent` where CustomerID=$userId");
    $absent = $result->fetch_all(MYSQLI_ASSOC);
    $result2=$conn->query("Select Date from Extra where CustomerID=$userId");
    $extra = $result2->fetch_all(MYSQLI_ASSOC);
 ?>