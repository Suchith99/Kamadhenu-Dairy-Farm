<?php
include "connect.php";
session_start();
extract($_POST);
$subject = "Reset Password OTP -Kamadhenu Dairy Farm";
$otp = mt_rand(10000,99999);
$_SESSION["password"]=$otp;
$txt="Hello ";
//$txt .= "Your one time password to reset your password is <h3><b>$otp</b></h3>";
//$txt .= "Thank You<br>Kamadhenu Dairy";
$headers = "From: no-reply@kamadhenu.com" . "\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
$to = $email;
$_SESSION["type"]=$type;
  //echo "Email - ".$email." Type ".$type." OTP - ".$otp;
  $result="a";
    if(strcasecmp($type,'Employee')==0)     
      $result = $conn->query("SELECT EmployeeID as id,Name FROM `Employee` WHERE Email = '$email'");
    else if(strcasecmp($type,'Customer')==0)
      $result = $conn->query("SELECT CustomerID as id,Name FROM `Customer` WHERE Email = '$email'");
    else
    {
      $result = $conn->query("SELECT OwnerID as id,Name FROM `Owner` WHERE Email = '$email'");
    }
    
    

     if($result->num_rows == 1)
     {
       while($row = $result->fetch_array())
       {
         $_SESSION['id']=$row['id'];  
         $txt.=$row['Name'].",<br>" ;
         $txt .= "Your one time password to reset your password is <h3><b>$otp</b></h3>";
         $txt .= "Thank You<br>Kamadhenu Dairy";
       }
       mail($to,$subject,$txt,$headers);
       echo "success";
     }
     else 
     {
         echo "failed";
     }
    // echo "okk";*/
     
 /*    extract($_POST);
     $otp = mt_rand(10000,99999);
     echo "Email - ".$email." Type ".$type." OTP - ".$otp;*/
?>