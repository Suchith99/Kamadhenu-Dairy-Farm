<?php
 include "connect.php";
 extract($_POST);

 try
 {
    $stmt = $conn->prepare("SELECT EmployeeID, Email, Password FROM Employee where Email = :email and Password = :key");
    $stmt->execute([':email'=>$Employeename,':key'=>$Employeepassword]);
    if($stmt->rowCount() === 0) echo('No rows');
    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC); 
    while($row=$stmt->fetch())
    {
        if($row['Email']==$Employeename&&$row['Password']==$Employeepassword)
            header("Location:Employee.php");
    }
 }
 catch(PDOException $e)
 {
    echo "Error: " . $e->getMessage();
 }
 $conn = null;
 
?>