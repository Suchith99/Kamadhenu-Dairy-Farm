function intervalPayment()
{
    var from =$("#payment-interval").val();
    if(from.indexOf("to")!=-1)
    {
        $("#p-from").html(from);
        $("#interval-payment").fadeIn("fast");
       $.post("customerPayment.php",{from:from},function(data){
       document.getElementById('table_content_payment').innerHTML=data;
    });
    }
    else
      alert("Select Dates");
}
function paymentHistory()
{
    $("#previous-payment").fadeIn("fast");

    $.post("customerPayment.php",{},function(data){
        document.getElementById('table_content_history').innerHTML=data;
    });
    
}