function confirmPayment() {
    var table = document.getElementById("singlePaymentTable").getElementsByTagName("tbody")[0];
    $("#singlePaymentTable tbody tr").remove();
        var row = table.insertRow();
        var cell1 = row.insertCell(0);
        var cell2=row.insertCell(1)
        var cell3 = row.insertCell(2);
        cell1.innerHTML = $("#payingcustomer option:selected").text();
        cell2.innerHTML = $("#paying").val();
        cell3.innerHTML = $("#paidon").val();
    
}

function singlePayment()
{
    var customer=$("#payingcustomer").val();
    var paidon=$("#paidon").val();
    var amount=$("#paying").val();
    var frm = document.getElementById('CustomerSinglePaymentForm');
    $("#single-payment").fadeOut("fast");
    frm.reset();
    $.post("Pay.php",{customer:customer,paidon:paidon,amount:amount},function(data){
        alert(data);
        $("#single-payment").fadeOut("fast");
    });
}

function checkDues()
{
    $("#due-list").fadeIn("fast");
    $.post("Pay.php",function(data){
        document.getElementById('due-details').innerHTML=data;
    });
}