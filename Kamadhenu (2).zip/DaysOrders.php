<?php
 include "connect.php";
 extract($_POST);
if(isset($_REQUEST['saledate']))
{
   $date=$saledate;
}
else if(isset($_REQUEST['orderdate']))
{
   $date=$orderdate;
}
if($date!=null)
{
$query="SELECT CustomerID,Name,Quantity,concat(Line1,' ',ifnull(Line2,''),' , ',City) as Address FROM `Customer`,Address WHERE Status=1 AND Customer.AddressID=Address.AddressID AND CustomerID NOT in (SELECT CustomerID FROM Absent WHERE Date ='".$date."')";

      $extraquery="select Customer.CustomerID,Name,Customer.quantity+Extra.Quantity as Quantity FROM Customer,Extra WHERE Customer.CustomerID=Extra.CustomerID and Date='".$date."'";
      $stmt = mysqli_query($conn,$query);
      $stmt2=mysqli_query($conn,$extraquery);


      while($row = mysqli_fetch_assoc($stmt))
      {
         $new_array[] = $row;
      }
      if (mysqli_num_rows($stmt2) > 0)
      {
        while( $row = mysqli_fetch_assoc( $stmt2))
        {
          $extra_array[] = $row; // Inside while loop
        }
        foreach($extra_array as $extrarow)
        {
          for($i=0;$i<count($new_array);$i++)
          {
             if($new_array[$i]['CustomerID']==$extrarow['CustomerID'])
             {
                $new_array[$i]['Quantity']=$extrarow['Quantity'];
                break;
             }
          }  
        }
      }
      if(isset($_REQUEST['saledate']))
      {
      $result= "<table id='daySaleTable' class='table table-striped table-condensed table-bordered'><thead><tr><th>Name</th><th>Quantity(in litres)</th><th>Delivered</th></tr></thead>";
      for($i=0;$i<count($new_array);$i++) 
      {
          //echo "Ok".$row['Name'];
         $result.= "<tr><td>".$new_array[$i]['Name']."</td><td id=".$new_array[$i]['CustomerID'].">".$new_array[$i]['Quantity']."</td><td><input type='checkbox' name='Customer' value=".$new_array[$i]['CustomerID']."></td></tr>";
      }
      }
      else if(isset($_REQUEST['orderdate']))
      {
        $result= "<table id='daySaleTable' class='table table-striped table-condensed table-bordered'><thead><tr><th>Name</th><th>Quantity(in litres)</th><th>Address</th></tr></thead>";
        for($i=0;$i<count($new_array);$i++) 
        {
          //echo "Ok".$row['Name'];
         $result.= "<tr><td>".$new_array[$i]['Name']."</td><td id=".$new_array[$i]['CustomerID'].">".$new_array[$i]['Quantity']."</td><td>".$new_array[$i]['Address']."</td></tr>";
        }     
      }
    echo $result;
}
?>