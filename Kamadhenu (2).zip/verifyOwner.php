<?php
ob_start();
 session_start();
 require "connect.php";
 extract($_POST);

    $flag=true;
    $result = $conn->query("SELECT OwnerID,Name,Email,Password FROM `Owner`");
    $rows = $result->fetch_all(MYSQLI_ASSOC);
    foreach($rows as $row)
    {
        if($row['Email']==$Ownername&&$row['Password']==$Ownerpassword)
        {
            $_SESSION['userId'] = $row['OwnerID']; 
            $_SESSION['Name'] = $row['Name'];
            $flag=true;
            echo $flag;
            //header('Location: Owner.php');
        }
        else 
        {
            $flag=false;
        }
    }
    if(!$flag)
      echo $flag;
?>