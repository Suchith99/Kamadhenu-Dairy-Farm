function confirmSale() {
    var table = document.getElementById("singleSaleTable").getElementsByTagName("tbody")[0];
    $("#singleSaleTable tbody tr").remove();
        var row = table.insertRow();
        var cell1 = row.insertCell(0);
        var cell2=row.insertCell(1)
        var cell3 = row.insertCell(2);
        cell1.innerHTML = $("#customer option:selected").text();
        cell2.innerHTML = $("#quant").val();
        cell3.innerHTML = $("#to").val();
    
}

function singleSale()
{
    var customer=$("#customer").val();
    var to=$("#to").val();
    var quant=$("#quant").val();
    var frm = document.getElementById('CustomerSingleSaleForm');
    $("#single-sale").fadeOut("fast");
    frm.reset();  // Reset all form data
    $.post("Sale.php",{customer:customer,to:to,quant:quant},function(response){
        alert(response);
    });
}

function daySale()
{

   var items=document.getElementsByName('Customer');
		var customer=new Array();
		var Quantity=new Array();
		for(var i=0; i<items.length; i++){
			if(items[i].type=='checkbox' && items[i].checked===true)
			{	
			    customer.push(items[i].value);
			    Quantity.push(document.getElementById(items[i].value).innerHTML);
			}
		}


  //  var customer=$("#Customer").val();
    var date=$("#saledate").val();
    var frm = document.getElementById('DaysSaleForm');
    $("#days-sale").fadeOut("fast");
    frm.reset();  // Reset all form data
    if(date!=="")
    $.post("Sale.php",{Customer:customer,saledate:date,Quantity},function(response){
        alert(response);
    });
}
